# Modulo para crear el Json que se envia a hacienda 
Se envia

w : makeJson
r : makeJson
clave : Clave numerica del comprobante
fecha : la fecha
emi_tipoIdentificacion : tipo identificacion receptor
emi_numeroIdentificacion : Numero de identifiacion del Receptor 
recp_tipoIdentificacion : tipo identificacion receptor
recp_numeroIdentificacion : Numero de identifiacion del Receptor
comprobanteXml : xml firmado y en base 64




