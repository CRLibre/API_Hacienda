# Modulo para firmar un XML
Se enviar                       
jarUrl:URL del servidor donde esta el jar para Firmar
p12Url:Url del Servidor deon esta el certificado
p12Pin:Pin del certificado
inXmlUrl: URL en el servidor donde esta el XML que se va a firmar
outXmlUrl: URL en el servidor donde va a salir el XML firmado





