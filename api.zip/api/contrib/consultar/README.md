# Modulo para hacer comprobar estado de los comprobantes
Se envia

w : consultar
r : consultarCom
clave : Clave numerica del comprobante
token: Token funcional para enviar en el header




